package com.pwskills.nitin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.pwksills.utility.JdbcUtil;

public class TransactionApp {

	// Driver code
	public static void main(String[] args) {

		try (Connection connection = JdbcUtil.getMySQLDBConection()) {

			try (Statement statement = connection.createStatement()) {
				
				try (ResultSet resultSet = statement.executeQuery("select * from accounts")) {
					System.out.println("Data before transaction....");
					while (resultSet.next()) {
						System.out.println(resultSet.getString(1) + " " + resultSet.getInt(2));
					}
				}
				System.out.println();
				
				System.out.println("******Transaction Begins...******");
				connection.setAutoCommit(false);
				
				//Starting the Transaction
				statement.executeUpdate("update accounts set balance = balance-5000 where name='sachin'");
				statement.executeUpdate("update accounts set balance = balance+5000 where name='dhoni'");
				
				
				//Confirming the Transaction
				Scanner scanner =new Scanner(System.in);
				System.out.print("Can u please confirm the transaction of 5000:[Yes/No]: ");
				String option =scanner.next();
				if (option.equalsIgnoreCase("yes")) {
					connection.commit();
					System.out.println("Transaction committed...");
				} else {
					connection.rollback();
					System.out.println("Transaction rolledback...");
				}
				
				System.out.println();
				
				//Printing the ResultSet information after the transcation
				try (ResultSet resultSet = statement.executeQuery("select * from accounts")) {
					System.out.println("Data after transaction....");
					while (resultSet.next()) {
						System.out.println(resultSet.getString(1) + " " + resultSet.getInt(2));
					}
				}
				scanner.close();
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
