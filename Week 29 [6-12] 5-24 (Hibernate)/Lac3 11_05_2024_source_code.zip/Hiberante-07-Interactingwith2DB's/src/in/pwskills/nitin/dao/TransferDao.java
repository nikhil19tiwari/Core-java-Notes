package in.pwskills.nitin.dao;

public interface TransferDao {
	public String transferProductById(Integer id);
}
