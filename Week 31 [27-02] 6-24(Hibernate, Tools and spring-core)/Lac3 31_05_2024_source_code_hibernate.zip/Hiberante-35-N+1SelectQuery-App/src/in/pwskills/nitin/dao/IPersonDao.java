package in.pwskills.nitin.dao;

public interface IPersonDao {

	// performing select operation using parent
	public void loadRecordUsingHQLJoin();
	public void loadRecordUsingQBCFetchTypeJoin();


}
