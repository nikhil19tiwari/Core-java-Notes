package com.pwskills.nitin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.pwksills.utility.JdbcUtil;

public class SQLInjectionUsingStatement {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		try (Connection connection = JdbcUtil.getOracleDBConection()) {

			try (Statement statement = connection.createStatement()) {

				System.out.print("Enter the username :: ");
				String username = scanner.next();
				username = "'" + username + "'";

				System.out.print("Enter the password :: ");
				String password = scanner.next();
				password = "'" + password + "'";

				String sqlSelectQuery = "select count(*) from users where name=" + username + " and password="
						+ password + " ";
				
				System.out.println(sqlSelectQuery);

				try (ResultSet resultSet = statement.executeQuery(sqlSelectQuery)) {
					
					int count = 0;
					if (resultSet.next()) {
							count = resultSet.getInt(1);
					} 
					
					if (count==1) {
						System.out.println("Valid credentials.....");
					} else {
						System.out.println("Invalid credentials....");
					}
				}
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		scanner.close();
	}

}
