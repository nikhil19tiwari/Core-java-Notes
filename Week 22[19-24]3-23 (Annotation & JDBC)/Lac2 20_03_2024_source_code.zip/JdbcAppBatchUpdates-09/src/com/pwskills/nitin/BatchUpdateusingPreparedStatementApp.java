package com.pwskills.nitin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.pwksills.utility.JdbcUtil;

public class BatchUpdateusingPreparedStatementApp {

	private static final String SQL_INSERT_QUERY = "insert into employees(`ename`,`esal`,`eaddress`) values(?,?,?)";

	// Driver code
	public static void main(String[] args) {

		try (Connection connection = JdbcUtil.getMySQLDBConection()) {

			try (PreparedStatement preparedStatement = connection.prepareStatement(SQL_INSERT_QUERY)) {

				Scanner scanner = new Scanner(System.in);

				while (true) {
					System.out.print("Enter the employee name :: ");
					String ename = scanner.next();

					System.out.print("Enter the employee esal :: ");
					int esal = scanner.nextInt();

					System.out.print("Enter the employee address :: ");
					String eaddress = scanner.next();

					preparedStatement.setString(1, ename);
					preparedStatement.setInt(2, esal);
					preparedStatement.setString(3, eaddress);

					// Adding the query to batch file
					preparedStatement.addBatch();

					System.out.print("Do u want to insert one more record:: [YES/NO]");
					String option = scanner.next();
					if (option.equalsIgnoreCase("no")) {
						break;
					}
				}

				// Exeucte the batch
				preparedStatement.executeBatch();
				System.out.println("Records inserted succesfully....");
				scanner.close();
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
