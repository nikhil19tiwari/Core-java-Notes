package com.pwskills.nitin;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.pwksills.utility.JdbcUtil;

public class BatcUpdateUsingStatementApp {

	// Driver code
	public static void main(String[] args) {

		try (Connection connection = JdbcUtil.getMySQLDBConection()) {

			try (Statement statement = connection.createStatement()) {

				// Adding the queries to batch file
				statement.addBatch("insert into employees(`ename`,`esal`,`eaddress`) values('shahid',25000,'RCB')");
				statement.addBatch("update employees set esal = esal+ 1000 where esal<30000");
				statement.addBatch("delete from employees where esal>35000");

				// Exeucte the batch
				int[] count = statement.executeBatch();

				int updateCount = 0;

				// process the output
				for (int result : count) {
					updateCount += result;
				}
				System.out.println("No of rows altered is :: " + updateCount);
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
