package com.pwskills.nitin;

import java.sql.Connection;
import java.sql.SQLException;

import com.pwksills.utility.JdbcUtil;

public class TransactionIsolationLevelsApp {

	// Driver code
	public static void main(String[] args) {

		try (Connection connection = JdbcUtil.getMySQLDBConection()) {

			System.out.println(connection.getTransactionIsolation());
			connection.setTransactionIsolation(8);
			System.out.println(connection.getTransactionIsolation());

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
