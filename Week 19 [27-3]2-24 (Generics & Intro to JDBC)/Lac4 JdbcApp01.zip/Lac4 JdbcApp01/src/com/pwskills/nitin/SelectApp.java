package com.pwskills.nitin;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.pwksills.utility.DBUtil;

public class SelectApp {
	public static void main(String[] args) {

		// Resources used
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;

		try {
			connection = DBUtil.getDBConection();

			// 2. Create a Statement Object
			statement = connection.createStatement();

			// 3. Execute the Query
			String SqlSelectQuery = "select sid,sname,sage,saddress from student";
			resultSet = statement.executeQuery(SqlSelectQuery);

			// 4. Process the Result
			System.out.println("SID\tSNAME\tSAGE\tSADDRESS");
			while (resultSet.next()) {
				System.out.println(resultSet.getInt(1) + "\t" + resultSet.getString(2) + "\t" + resultSet.getInt(3)
						+ "\t" + resultSet.getString(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.cleanUpResources(resultSet, statement, connection);
		}
	}
}
