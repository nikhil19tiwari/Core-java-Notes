package com.pwskills.nitin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.pwksills.utility.JdbcUtil;

public class ResultSetScrollUpdatableApp {

	// Driver code
	public static void main(String[] args) {

		try (Connection connection = JdbcUtil.getMySQLDBConection()) {

			try (Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_UPDATABLE)) {

				try (ResultSet resultSet = statement.executeQuery("select eid,ename,esal,eaddress from employees")) {
					while (resultSet.next()) {
						// perform update operation
						int salary = resultSet.getInt(3);
						if (salary <= 28000) {
							int incrSalary = salary + 10000;
							resultSet.updateInt(3, incrSalary);
							resultSet.updateRow();
						}
					}
					System.out.println("Records updated....");
				}
			}

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
