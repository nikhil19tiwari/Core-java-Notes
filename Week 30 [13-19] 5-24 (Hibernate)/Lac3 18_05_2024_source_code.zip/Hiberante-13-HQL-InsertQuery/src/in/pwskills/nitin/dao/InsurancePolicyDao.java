package in.pwskills.nitin.dao;

public interface InsurancePolicyDao {
	public String transferPolicies(int minTenure);
}
