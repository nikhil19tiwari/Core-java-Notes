package com.pwskills.nitin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.pwksills.utility.DBUtil;

public class UpdateApp {

	public static void main(String[] args) {

		// Resource used
		Connection connection = null;
		Statement statement = null;
		int rowCount = 0;

		try {
			connection = DBUtil.getDBConection();

			if (connection != null)
				statement = connection.createStatement();

			Scanner scanner = new Scanner(System.in);

			String sqlUpdateQuery = null;
			if (scanner != null) {
				System.out.print("Enter the sid:: ");
				int sid = scanner.nextInt();
				System.out.print("Enter the sname:: ");
				String sname = scanner.next();
				sname = "'" + sname + "'";
				
				sqlUpdateQuery = "update student set sname="+sname+"where sid ="+sid+"";
				System.out.println(sqlUpdateQuery);
			}
			if (statement != null && sqlUpdateQuery != null)
				rowCount = statement.executeUpdate(sqlUpdateQuery);
			if (rowCount == 0)
				System.out.println("Record not availabe for updation .....");
			else
				System.out.println("Record updated succesfully.....");

			scanner.close();

		} catch (IOException | SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.cleanUpResources(null, statement, connection);
		}
	}
}
