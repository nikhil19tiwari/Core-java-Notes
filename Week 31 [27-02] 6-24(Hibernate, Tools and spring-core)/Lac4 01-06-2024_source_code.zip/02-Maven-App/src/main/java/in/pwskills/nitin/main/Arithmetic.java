package in.pwskills.nitin.main;


public class Arithmetic 
{
	//method for testing
    public int add(int x,int y)
	{
		return x+y;
	}
}
