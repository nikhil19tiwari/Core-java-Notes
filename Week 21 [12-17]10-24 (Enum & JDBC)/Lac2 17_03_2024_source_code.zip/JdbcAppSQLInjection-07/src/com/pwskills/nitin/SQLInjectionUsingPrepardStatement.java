package com.pwskills.nitin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.pwksills.utility.JdbcUtil;

public class SQLInjectionUsingPrepardStatement {

	private static final String SQL_SELECT_QUERY = "select count(*) from users where name=? and password = ?";

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		try (Connection connection = JdbcUtil.getOracleDBConection()) {

			try (PreparedStatement preparedStatement = connection.prepareStatement(SQL_SELECT_QUERY)) {

				System.out.print("Enter the username :: ");
				String username = scanner.next();

				System.out.print("Enter the password :: ");
				String password = scanner.next();

				// Set the values to ? placeholder(trying to perform SQLINJECTION)
				preparedStatement.setString(1, username);
				preparedStatement.setString(2, password);

				System.out.println(SQL_SELECT_QUERY);
				
				try (ResultSet resultSet = preparedStatement.executeQuery()) {

					int count = 0;
					if (resultSet.next()) {
						count = resultSet.getInt(1);
					}

					if (count == 1) {
						System.out.println("Valid credentials.....");
					} else {
						System.out.println("Invalid credentials....");
					}
				}
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		scanner.close();
	}

}
