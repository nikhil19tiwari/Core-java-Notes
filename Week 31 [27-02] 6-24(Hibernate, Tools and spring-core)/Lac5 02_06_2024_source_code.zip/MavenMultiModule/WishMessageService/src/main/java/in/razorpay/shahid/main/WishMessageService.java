package in.razorpay.shahid.main;

public class WishMessageService {
	public String wishUser(String username) {
		return "Good Evening :: "+username;
	}
}
